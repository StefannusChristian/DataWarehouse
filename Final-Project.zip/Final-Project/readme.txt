Final Project - IBDA4011 Gudang Data 
Anggota Kelompok:
1. Dominique Huang - 202000216
2. Stefannus Christian - 202000138
3. Victor Chendra - 202000338
4. Wira Yudha - 202000536


How to run:
1. run `init_db.py`
2. open console (cmd)
3. paste --> `streamlit run __main__.py`
4. by default, the app should open your browser and redirect you to it. 
   if not, you can paste this link to your browser "http://localhost:8501/" 


Komitmen Integritas:
Di hadapan TUHAN yang hidup, saya menegaskan bahwa saya tidak memberikan maupun menerima bantuan apapun—baik
lisan, tulisan, maupun elektronik—di dalam ujian ini selain daripada apa yang telah diizinkan oleh pengajar, 
dan tidak akan menyebarkan baik soal maupun jawaban ujian kepada pihak lain.
