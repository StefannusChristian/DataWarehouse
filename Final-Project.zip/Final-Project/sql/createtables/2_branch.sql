CREATE TABLE IF NOT EXISTS branch (
    branch_id INT PRIMARY KEY,
    branch_name VARCHAR(255),
    location VARCHAR(255)
);